# Main code for ICE+
# ----------------------------------------------------------------
# Creation: 07/03/2019
# Last modified: 08/20/2021
# ----------------------------------------------------------------


# # =========================================================================== #
# #                             1. INITIALIZATION
# # =========================================================================== #
# 
# Clear workspace
rm(list = ls())
graphics.off()

# packages
library(MARSS)
library(ggplot2)
library(dplyr)
library(reshape2)
library(forecast)
library(factoextra)
library(astsa)
library(scales)
library(gridExtra)
library(xtable)
library(stringr)

# working directory for the Replication Files
wd = '~/ICEplus/ReplicationFiles'

setwd(wd)

# auxiliary subfunctions
source('./code/tools.R')

set.seed(1)

# =========================================================================== #
#                         2. LOAD RAW DATA
# =========================================================================== #

## load sea ice extent
multi_extent = read.csv('./data/MergedRawData.csv')

nobs = nrow(multi_extent)

# create a column for date
start_year  = multi_extent$Year[1]
start_month = multi_extent$Month[1]
end_year    = multi_extent$Year[nrow(multi_extent)]
end_month   = multi_extent$Month[nrow(multi_extent)]

multi_extent$Date = seq(start_year + (start_month-1)/12, end_year + (end_month-1)/12, by = 1/12)

## impute missing values 
## 12/1987 and 01/1988 Sii & Goddard are missing
# fill the two missing months using a forecast from a benchmark climatological model with fixed linear trend and fixed monthly dummies,
# estimated using data 11/1978 - 11/1987

which(is.na(multi_extent$Sii_Extent))
which(is.na(multi_extent$Goddard_Extent))
which(is.na(multi_extent$Bremen_Extent))
which(is.na(multi_extent$Jaxa_Extent))

# impute missing value with predicted value
period_end = which(is.na(multi_extent$Sii_Extent))[1]-1
ext_model = lm(Sii_Extent ~ Year + factor(Month), data = multi_extent[1:period_end,])
multi_extent$Sii_Extent[is.na(multi_extent$Sii_Extent)] = predict(ext_model, newdata = multi_extent[is.na(multi_extent$Sii_Extent), 1:2])

ext_model = lm(Goddard_Extent ~ Year + factor(Month), data = multi_extent[1:period_end,])
multi_extent$Goddard_Extent[is.na(multi_extent$Goddard_Extent)] = predict(ext_model, newdata = multi_extent[is.na(multi_extent$Goddard_Extent), 1:2])

## time series of extent
y = ts(multi_extent[,3:6], start = c(start_year,start_month), end = c(end_year, end_month), frequency = 12)

# create dataset to be used in the analysis
mat_temp =  multi_extent
mat_temp$Month = factor(mat_temp$Month)
mat_temp$Trend = 1:nrow(multi_extent)

# =========================================================================== #
#                 3. KALMAN FILTER (with intercept), lambda_S = 1
# =========================================================================== #
set.seed(1)

# transition equation
B = "unconstrained"
U = "zero"
C = matrix(c(month.abb, paste0(month.abb,'Time'), paste0(month.abb,'Time_SQ')), 1, 36, byrow = TRUE)
c = model.matrix(lm(Bremen_Extent ~ Month + Month:Trend + Month:I(Trend^2) - 1, mat_temp))
c = t(c)
Q = matrix(list("q"), 1, 1)

# measurement equation
Z = matrix(list(1,"z2","z3",'z4'), 4, 1)
A = matrix(list(0,"a2","a3",'a4'), 4, 1)
D = "zero"
d = "zero"
R = 'unconstrained'

# initial values
x0 = matrix(multi_extent$Sii_Extent[1], 1, 1)
V0 = "unconstrained"

# create model
model = list(B = B, U = U, C = C, c = c, Q = Q,
             Z = Z, A = A, D = D, d = d, R = R,
             x0 = x0, V0 = V0, tinitx = 0)

dat = t(matrix(y, nrow(y), ncol(y)))

# Kalman Filtering (take fairly long time to get the results)
kemfit_S = MARSS(dat, model = model, control = list(maxit = 10000, trace = 1), silent = T)
# get estimates from Kalman filter and smoother
kf_S = MARSSkfss(kemfit_S)
# generate standard Errors, Confidence Intervals and Bias for MARSS Parameters
kf_CI_S = MARSSparamCIs(kemfit_S)


# VCV matrix
b = matrix(0, ncol(y), ncol(y))
b[lower.tri(b, diag=T)] <- kemfit_S$par$R
b <- t(b)
b[lower.tri(b, diag=T)] = kemfit_S$par$R
round(b, 3)
round(cov2cor(b), 3)





# =========================================================================== #
#                 4. KALMAN FILTER (add intercept), lambda_G = 1
# =========================================================================== #

set.seed(1)

# transition equation
B = "unconstrained"
U = "zero"
C = matrix(c(month.abb, paste0(month.abb,'Time'), paste0(month.abb,'Time_SQ')), 1, 36, byrow = TRUE)
c = model.matrix(lm(Bremen_Extent ~ Month + Month:Trend + Month:I(Trend^2) - 1, mat_temp))
c = t(c)
Q = matrix(list("q"), 1, 1)

# measurement equation
Z = matrix(list("z1","z2",'z3',1), 4, 1)
A = matrix(list("a1","a2","a3",0), 4, 1)
D = "zero"
d = "zero"
R = 'unconstrained'

# initial values
x0 = matrix(multi_extent$Sii_Extent[1], 1, 1)
V0 = "unconstrained"

# create model
model = list(B = B, U = U, C = C, c = c, Q = Q,
             Z = Z, A = A, D = D, d = d, R = R,
             x0 = x0, V0 = V0, tinitx = 0)

dat = t(matrix(y, nrow(y), ncol(y)))
# perform Kalman Filter
kemfit_G = MARSS(dat, model = model, control = list(maxit = 10000, trace = 1), silent = T)
# get Kalman filter and smoother
kf_G = MARSSkfss(kemfit_G)
# generate standard Errors, Confidence Intervals and Bias for MARSS Parameters
kf_CI_G = MARSSparamCIs(kemfit_G)


# VCV matrix
b = matrix(0, ncol(y), ncol(y))
b[lower.tri(b, diag=T)] <- kemfit_G$par$R
b <- t(b)
b[lower.tri(b, diag=T)] = kemfit_G$par$R
round(b, 3)
round(cov2cor(b), 3)




# =========================================================================== #
#                         5. OUTPUT
# =========================================================================== #

# save ice extent and ice+ in csv files
output_mat = cbind(multi_extent, as.vector(kf_S$xtT), as.vector(kf_G$xtT))
output_mat = output_mat[, !colnames(output_mat) %in% c('Date',"volume","thickness")]
colnames(output_mat)[ncol(output_mat)-1] = 'Latent_S'
colnames(output_mat)[ncol(output_mat)-0] = 'Latent_G'
write.csv(output_mat, file= './data/ice_with_dts_latent_addIntercept.csv', row.names = F)